# mywc

Writting my own wc Unix tool